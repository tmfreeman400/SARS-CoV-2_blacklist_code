#Select directory in which to run project
#Input is filepath to project directory
var1=$1

cd $var1

#Create directories and subdirectories for all chromosomes
for i in {1}
do
  mkdir chr$i
done
