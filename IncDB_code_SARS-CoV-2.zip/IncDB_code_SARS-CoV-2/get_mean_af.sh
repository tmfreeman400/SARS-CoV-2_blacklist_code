#!/bin/bash

#First input is filepath to project directory
#Second input is chromosome number
var1=$1
var2=$2
c="/chr"

cd $var1$c$var2

#Maximum size is 32,000 bp
solosize=32000
numchunks=1
echo $numchunks

currentchunk=1
maxco=32000
#Generate chunks
tag="_mchunk"
for file in *soloDB; do
awk -v maxc=$maxco 'NR==1, NR==maxc-1; NR==maxc {print; exit}' $file > $file$tag$currentchunk
done;
#Do for loop for mawk code over chunks to calculate mean (aggregate) allelic frequencies
mawk '{a[FNR]+=$1; b[FNR]++;
d[FNR]+=$2; e[FNR]++;
g[FNR]+=$3; h[FNR]++;
j[FNR]+=$4; k[FNR]++;
m[FNR]+=$5; n[FNR]++;
p[FNR]+=$6; q[FNR]++;}
	END{
	  for(i=1;i<=FNR;i++)
	    print a[i]/b[i],
                  d[i]/e[i],
                  g[i]/h[i],
                  j[i]/k[i],
                  m[i]/n[i],
                  p[i]/q[i]
 ;
   }' *soloDB$tag$currentchunk > meanAF$tag$currentchunk.txt
currentchunk=`echo $((1+$currentchunk))`

#Merge chunks into output (only 1 chunk, so this step is trivial)
currentchunk=1
cat meanAF_mchunk1.txt > meanAF.txt

#Delete chunks and temporary files
rm *meanAF_mchunk?.txt
rm *mchunk?
